/**
 * Stone Ove — Menu Data
 * Contains all categories, items, hero slides, and pickup locations.
 * Each item has a real food photo (img) assigned by category/type.
 */

/* ─────────────────── Hero Slides ─────────────────── */
const HERO_SLIDES = [
  {
    eyebrow: "Now Trending",
    title: "Voted the city's favourite wood-fired pizza",
    subtitle: "Thank you for four years of stone-baked crusts and full tables.",
  },
  {
    eyebrow: "New This Season",
    title: "Signature Pizza edit, back in the oven",
    subtitle: "Six new flavours built around our house-made Behari kabab sauce.",
  },
  {
    eyebrow: "Delivery",
    title: "Now delivering citywide, every single day",
    subtitle: "Order ahead for pickup, or have it delivered hot in under 40 minutes.",
  },
];

/* ─────────────────── Pickup Locations ─────────────────── */
const PICKUP_LOCATIONS = [
  "Gulberg, Faisalabad",
  "Satellite Town, Rawalpindi",
  "Main Boulevard, Lahore",
];

/* ─────────────────── Image Bank ─────────────────── */
// Multiple pizza images for variety
const PIZZA_IMGS = [
  "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=500&q=80",
  "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=500&q=80",
  "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80",
  "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=500&q=80",
  "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=500&q=80",
  "https://images.unsplash.com/photo-1548369937-47519962c11a?w=500&q=80",
  "https://images.unsplash.com/photo-1506354666786-959d6d497f1a?w=500&q=80",
  "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=500&q=80",
];

const IMGS = {
  // Deals / Combos — pizza deal shows a real pizza + drink spread
  deal_pizza:      "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=500&q=80",
  deal_chicken:    "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=500&q=80",
  deal_burger:     "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80",
  deal_wings:      "https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=500&q=80",
  // Kids
  kids_meal:       "https://images.unsplash.com/photo-1619881585019-882f0b9ab6a6?w=500&q=80",
  // Appetizers
  fries:           "https://images.unsplash.com/photo-1630431341973-02e1b662ec35?w=500&q=80",
  curly_fries:     "https://images.unsplash.com/photo-1630431341973-02e1b662ec35?w=500&q=80",
  nuggets:         "https://images.unsplash.com/photo-1562967914-608f82629710?w=500&q=80",
  wings:           "https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=500&q=80",
  garlic_bread:    "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&q=80",
  cheese_sticks:   "https://images.unsplash.com/photo-1541014741259-de529411b96a?w=500&q=80",
  kabab_platter:   "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=500&q=80",
  loaded_fries:    "https://images.unsplash.com/photo-1630431341973-02e1b662ec35?w=500&q=80",
  // Pasta
  pasta:           "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=500&q=80",
  lasagna:         "https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=500&q=80",
  // Burgers
  burger:          "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80",
  zinger:          "https://images.unsplash.com/photo-1553979459-d2229ba7433b?w=500&q=80",
  fried_chicken:   "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=500&q=80",
  hot_wings:       "https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=500&q=80",
  // Sandwich & Rolls
  sandwich:        "https://images.unsplash.com/photo-1539252554453-80ab65ce3586?w=500&q=80",
  roll:            "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=500&q=80",
  // Salad & Sauce
  salad:           "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=500&q=80",
  dip_sauce:       "/img/mayo_dip.png",
  // Desserts
  ice_cream:       "https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=500&q=80",
  chocolate_lava:  "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=500&q=80",
  brownie:         "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=500&q=80",
  sundae:          "https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=500&q=80",
  // Beverages
  soft_drink:      "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?w=500&q=80",
  water:           "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=500&q=80",
};

/* ─────────────────── Category → Item Definitions ─────────────────── */
const CATEGORIES = [
  {
    id: "newly-launched",
    label: "Newly Launched",
    items: [
      {
        name: "Curly Fries",
        desc: "Crispy spiral-cut fries tossed in seasoned salt and our signature spice blend.",
        price: 480, salePrice: 430,
        img: IMGS.curly_fries,
      },
    ],
  },
  {
    id: "kids-meal",
    label: "Kids Meal",
    items: [
      {
        name: "Kiddie Meal 1",
        desc: "Mini burger, fries, juice box, and a surprise toy.",
        price: 650, salePrice: 590,
        img: IMGS.kids_meal,
      },
      {
        name: "Kiddie Meal 2",
        desc: "Chicken nuggets, fries, juice box, and a surprise toy.",
        price: 690, salePrice: 620,
        img: IMGS.nuggets,
      },
    ],
  },
  {
    id: "takeaway-delivery-deals",
    label: "Takeaway & Delivery Deals",
    items: [
      {
        name: "Deal 1",
        desc: "1 regular pizza (any flavour) + 1 soft drink.",
        price: 1450, salePrice: 1290,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Deal 2",
        desc: "1 regular pizza (any flavour) + 2 soft drinks + garlic bread.",
        price: 1850, salePrice: 1650,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Deal 3",
        desc: "1 large pizza (any flavour) + 2 soft drinks.",
        price: 2350, salePrice: 2150,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Deal 4",
        desc: "1 extra-large pizza (special flavour) + 2 soft drinks.",
        price: 2950, salePrice: 2650,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
    ],
  },
  {
    id: "lunch-treats",
    label: "Lunch Treats",
    items: [
      {
        name: "Treat 1",
        desc: "1 regular pizza (any flavour) + 1 soft drink.",
        price: 1550, salePrice: 1345,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Treat 2",
        desc: "1 extra-large pizza (any flavour) + 1L soft drink.",
        price: 2750, salePrice: 2545,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Treat 3",
        desc: "1 large pizza (any flavour) + 1L soft drink.",
        price: 2850, salePrice: 2645,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Treat 4",
        desc: "1 large pizza (special flavour) + 1 skewer + 1L soft drink.",
        price: 2850, salePrice: 2645,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
    ],
  },
  {
    id: "any-time-deals",
    label: "Any Time Deals",
    items: [
      {
        name: "Deal 1",
        desc: "1 regular pizza (special flavour) + 1L soft drink.",
        price: 2270, salePrice: 2070,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Deal 2",
        desc: "1 large pizza (any flavour) + 1L soft drink.",
        price: 2740, salePrice: 2540,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Deal 3",
        desc: "1 small pizza (any flavour) + 1 regular soft drink.",
        price: 1180, salePrice: 985,
        img: IMGS.deal_pizza,
        hasPizza: true,
      },
      {
        name: "Deal 4",
        desc: "6 pcs fried chicken + 1L soft drink.",
        price: 2080, salePrice: 1885,
        img: IMGS.deal_chicken,
      },
      {
        name: "Deal 5",
        desc: "6 crunch burgers + fried chicken + 1L soft drink.",
        price: 3145, salePrice: 2945,
        img: IMGS.deal_burger,
      },
      {
        name: "Deal 6",
        desc: "6 zinger burgers + large fries + 1L soft drink.",
        price: 3395, salePrice: 3195,
        img: IMGS.deal_burger,
      },
      {
        name: "Deal 7",
        desc: "15 hot wings + 1 regular soft drink.",
        price: 1055, salePrice: 855,
        img: IMGS.deal_wings,
      },
    ],
  },
  {
    id: "box-meals",
    label: "Box Meals",
    items: [
      {
        name: "Box 1",
        desc: "3 pcs fried chicken + 1 regular soft drink.",
        price: 940, salePrice: 840,
        img: IMGS.deal_chicken,
      },
      {
        name: "Box 2",
        desc: "3 pcs fried chicken + fries + 500ml soft drink.",
        price: 1410, salePrice: 1210,
        img: IMGS.deal_chicken,
      },
      {
        name: "Box 3",
        desc: "2 zinger burgers + regular soft drink.",
        price: 1520, salePrice: 1320,
        img: IMGS.zinger,
      },
      {
        name: "Box 4",
        desc: "2 crunch burgers + regular fries + 500ml soft drink.",
        price: 1300, salePrice: 1100,
        img: IMGS.deal_burger,
      },
    ],
  },
  {
    id: "appetizers",
    label: "Appetizers",
    items: [
      {
        name: "Jalapeño Cheese Sticks",
        desc: "Mozzarella cheese and jalapeños, breaded and fried golden.",
        price: 645, salePrice: 545,
        img: IMGS.cheese_sticks,
      },
      {
        name: "Malai Boti Platter",
        desc: "5 pcs signature kabab boti stuffed with creamy cheese.",
        price: 855, salePrice: 745,
        img: IMGS.kabab_platter,
      },
      {
        name: "Stone Ove Platter",
        desc: "5 pcs signature kabab boti stuffed with cheese, special sauce.",
        price: 855, salePrice: 745,
        img: IMGS.kabab_platter,
      },
      {
        name: "Chapli Kabab Platter",
        desc: "5 pcs chapli kabab boti topped with our special house sauce.",
        price: 845, salePrice: 745,
        img: IMGS.kabab_platter,
      },
      {
        name: "Behari Kabab Platter",
        desc: "5 pcs of spiced kabab boti with onion and jalapeño.",
        price: 845, salePrice: 745,
        img: IMGS.kabab_platter,
      },
      {
        name: "Chicken Cheese Sticks",
        desc: "Mozzarella cheese and chicken, breaded and fried to perfection.",
        price: 690, salePrice: 590,
        img: IMGS.cheese_sticks,
      },
      {
        name: "French Fries",
        desc: "Fresh potatoes, natural cut and golden fried.",
        price: 380, salePrice: 340,
        img: IMGS.fries,
      },
      {
        name: "Loaded Fries",
        desc: "French fries topped with jalapeño, chicken, and drizzled sauce.",
        price: 690, salePrice: 590,
        img: IMGS.loaded_fries,
      },
      {
        name: "Chicken Nuggets",
        desc: "Golden fried bite-sized nuggets, served with your choice of dip.",
        price: 600, salePrice: 500,
        img: IMGS.nuggets,
      },
      {
        name: "Oven Baked Hot Wings",
        desc: "Baked hot wings, tossed generously in our house spice blend.",
        price: 690, salePrice: 590,
        img: IMGS.wings,
      },
      {
        name: "Garlic Bread Supreme",
        desc: "Freshly baked garlic bread generously topped with mozzarella.",
        price: 685, salePrice: 585,
        img: IMGS.garlic_bread,
      },
      {
        name: "Garlic Bread",
        desc: "Four pieces of freshly baked, buttery garlic bread.",
        price: 585, salePrice: 485,
        img: IMGS.garlic_bread,
      },
    ],
  },
  {
    id: "signature-pizza",
    label: "Signature Pizza",
    isPizza: true,
    items: [
      {
        name: "Chicken Behari Kabab",
        desc: "Signature chicken behari kabab with grilled onion and house chilli sauce.",
        price: 1027, salePrice: 897,
        img: PIZZA_IMGS[0],
      },
      {
        name: "Stone Ove Special",
        desc: "House combination of 3 signature flavours baked in one pie.",
        price: 1027, salePrice: 897,
        img: PIZZA_IMGS[1],
      },
    ],
  },
  {
    id: "favourite-pizza",
    label: "Favourite Pizza",
    isPizza: true,
    items: [
      {
        name: "Mexican Chipotle Pizza",
        desc: "Chipotle sauce topped with mozzarella cheese and seasoned chicken.",
        price: 927, salePrice: 797,
        img: PIZZA_IMGS[2],
      },
      {
        name: "Chapli Kabab Pizza",
        desc: "Spicy chapli kabab, capsicum, sweet corn, and mozzarella.",
        price: 927, salePrice: 797,
        img: PIZZA_IMGS[3],
      },
      {
        name: "Peri Peri Pizza",
        desc: "Fiery peri peri sauce with chicken tikka and fresh capsicum.",
        price: 927, salePrice: 797,
        img: PIZZA_IMGS[4],
      },
      {
        name: "Malai Boti Pizza",
        desc: "A rich steak sauce blend with grilled chicken malai boti.",
        price: 927, salePrice: 797,
        img: PIZZA_IMGS[5],
      },
    ],
  },
  {
    id: "classic-pizza",
    label: "Classic Pizza",
    isPizza: true,
    items: [
      {
        name: "The Euro",
        desc: "A mouth-watering blend of picante sauce, smoked chicken, capsicum, sausages, mushrooms, tomatoes and olives.",
        price: 575, salePrice: 517.5,
        img: PIZZA_IMGS[6],
      },
      {
        name: "Steak Supreme",
        desc: "A delightful blend of steak chicken, smoked sausages, and rich cheese.",
        price: 575, salePrice: 517.5,
        img: PIZZA_IMGS[7],
      },
      {
        name: "Mayo Garlic",
        desc: "House special mayo garlic sauce with chicken and mushroom.",
        price: 575, salePrice: 517.5,
        img: PIZZA_IMGS[0],
      },
      {
        name: "Cheesy Cheese",
        desc: "Topped with generous amounts of mozzarella and a lot more cheese.",
        price: 575, salePrice: 517.5,
        img: PIZZA_IMGS[1],
      },
    ],
  },
  {
    id: "traditional-pizza",
    label: "Traditional Pizza",
    isPizza: true,
    items: [
      {
        name: "Chicken Supreme",
        desc: "Spicy chicken, smoked chicken rolls, and golden sausage.",
        price: 490, salePrice: 430,
        img: PIZZA_IMGS[2],
      },
      {
        name: "Chicken Tikka",
        desc: "Tender chunks of marinated grilled chicken with house sauce.",
        price: 490, salePrice: 430,
        img: PIZZA_IMGS[3],
      },
      {
        name: "Chicken Fajita",
        desc: "A signature blend of grilled fajita chicken on a crispy base.",
        price: 490, salePrice: 430,
        img: PIZZA_IMGS[4],
      },
      {
        name: "Fajita Sicilian",
        desc: "A hearty combination of fajita chicken and smoked sausage.",
        price: 490, salePrice: 430,
        img: PIZZA_IMGS[5],
      },
      {
        name: "Sweet Corn",
        desc: "A hearty combination of fajita chicken and sweet corn.",
        price: 490, salePrice: 430,
        img: PIZZA_IMGS[6],
      },
      {
        name: "Veggie Lover",
        desc: "Loaded with fresh capsicum, tomatoes, mushroom, and olives.",
        price: 490, salePrice: 430,
        img: PIZZA_IMGS[7],
      },
    ],
  },
  {
    id: "kabab-crust",
    label: "Kabab Crust",
    isPizza: true,
    items: [
      {
        name: "Crown Crust Pizza",
        desc: "A mouthful of special seekh kabab baked into every crust bite.",
        price: 1863, salePrice: 1663,
        img: PIZZA_IMGS[0],
      },
      {
        name: "Stuffed Crust Pizza",
        desc: "Cheese-filled pizza edge, stuffed crust all the way around.",
        price: 1863, salePrice: 1663,
        img: PIZZA_IMGS[1],
      },
    ],
  },
  {
    id: "pasta",
    label: "Pasta",
    items: [
      {
        name: "Stone Ove Special Pasta",
        desc: "A rich and creamy white sauce pasta with fresh vegetables.",
        price: 963, salePrice: 863,
        img: IMGS.pasta,
      },
      {
        name: "Lasagna",
        desc: "Layers of noodles filled with rich, creamy bechamel and meat sauce.",
        price: 715, salePrice: 615,
        img: IMGS.lasagna,
      },
      {
        name: "Fettuccine",
        desc: "Strips of marinated chicken in a luxurious creamy sauce.",
        price: 963, salePrice: 863,
        img: IMGS.pasta,
      },
      {
        name: "Crunchy Chicken Pasta",
        desc: "Crispy chicken strips tossed through creamy pasta.",
        price: 963, salePrice: 863,
        img: IMGS.pasta,
      },
    ],
  },
  {
    id: "burgers",
    label: "Burgers",
    items: [
      {
        name: "FireMax Burger",
        desc: "Crispy chicken fillet, sriracha lettuce, and fresh jalapeño.",
        price: 470, salePrice: 415,
        img: IMGS.burger,
        badge: "Top Trending",
      },
      {
        name: "Zinger Burger",
        desc: "Crispy fried chicken fillet, fresh lettuce, and house mayo.",
        price: 465, salePrice: 415,
        img: IMGS.zinger,
      },
      {
        name: "Crunch Burger",
        desc: "Crunchy chicken fillet with cheese slice and fresh lettuce.",
        price: 335, salePrice: 285,
        img: IMGS.burger,
      },
      {
        name: "Patty Burger",
        desc: "Grilled chicken patty, lettuce, mayo, and sesame bun.",
        price: 335, salePrice: 285,
        img: IMGS.burger,
      },
      {
        name: "Fried Chicken (1 pc)",
        desc: "Golden fried, crisp on the outside, juicy and tender inside.",
        price: 335, salePrice: 285,
        img: IMGS.fried_chicken,
      },
      {
        name: "Zinger Stacker",
        desc: "Double fillet zinger burger with double cheese.",
        price: 605, salePrice: 505,
        img: IMGS.zinger,
      },
      {
        name: "Hot Wings (5 pcs)",
        desc: "Tossed in our house hot sauce, served crisp and juicy.",
        price: 580, salePrice: 480,
        img: IMGS.hot_wings,
      },
    ],
  },
  {
    id: "sandwiches",
    label: "Sandwiches",
    items: [
      {
        name: "Grilled Chicken Sandwich",
        desc: "Freshly baked on sesame bread, grilled chicken fillet, served hot.",
        price: 679, salePrice: 579,
        img: IMGS.sandwich,
      },
    ],
  },
  {
    id: "chicken-spin-rolls",
    label: "Chicken Spin Rolls",
    items: [
      {
        name: "Chapli Kabab Spin Roll",
        desc: "Four spin rolls stuffed with spiced chapli kabab and sauce.",
        price: 495, salePrice: 415,
        img: IMGS.roll,
      },
      {
        name: "Malai Boti Spin Roll",
        desc: "Four spin rolls stuffed with creamy malai boti.",
        price: 495, salePrice: 415,
        img: IMGS.roll,
      },
      {
        name: "Behari Kabab Spin Roll",
        desc: "Four spin rolls stuffed with juicy behari kabab.",
        price: 495, salePrice: 415,
        img: IMGS.roll,
      },
    ],
  },
  {
    id: "salad-bar",
    label: "Salad Bar",
    items: [
      {
        name: "Salad Bowl",
        desc: "Fresh seasonal greens — serve as a side dish or a light snack.",
        price: 400, salePrice: 340,
        img: IMGS.salad,
      },
    ],
  },
  {
    id: "dip-sauce",
    label: "Dip Sauce",
    items: [
      {
        name: "Mayo Dip Sauce",
        desc: "House-made creamy mayo dip sauce, served on the side.",
        price: 97, salePrice: 80,
        img: IMGS.dip_sauce,
      },
    ],
  },
  {
    id: "desserts",
    label: "Desserts",
    items: [
      {
        name: "Jumbo Treat",
        desc: "Warm vanilla ice cream sundae with waffle cone bits.",
        price: 445, salePrice: 385,
        img: IMGS.sundae,
      },
      {
        name: "Ice Cream Scoop",
        desc: "One generous scoop of your choice flavour, served fresh.",
        price: 385, salePrice: 320,
        img: IMGS.ice_cream,
      },
      {
        name: "Chocolate Lava",
        desc: "Rich chocolate cake with a warm molten center. A dessert classic.",
        price: 445, salePrice: 385,
        img: IMGS.chocolate_lava,
      },
      {
        name: "Chocolate Brownie",
        desc: "A warm rich chocolate brownie, served with a dusting of powdered sugar.",
        price: 480, salePrice: 415,
        img: IMGS.brownie,
      },
    ],
  },
  {
    id: "beverages",
    label: "Beverages",
    items: [
      {
        name: "Soft Drink (Bottle)",
        desc: "Your choice of cold soft drink — 1.5L bottle. Ask for flavours.",
        price: 78, salePrice: 65,
        img: IMGS.soft_drink,
      },
      {
        name: "Soft Drink (Can)",
        desc: "Chilled soft drink can, choice of Pepsi, 7UP, or Mirinda.",
        price: 85, salePrice: 65,
        img: IMGS.soft_drink,
      },
      {
        name: "Mineral Water",
        desc: "500ml chilled mineral water.",
        price: 78, salePrice: 65,
        img: IMGS.water,
      },
    ],
  },
];

/* ─────────────────── Pizza Sizes ─────────────────── */
// Base price is for P.Pan; others scale by multiplier
const PIZZA_SIZES = [
  { label: "Personal Pan", multiplier: 1 },
  { label: "Regular",      multiplier: 2.2 },
  { label: "Large",        multiplier: 3.1 },
  { label: "Extra Large",  multiplier: 4.7 },
];

/* ─────────────────── Add-Ons ─────────────────── */
const ADDONS = [
  { label: "Extra Cheese",         price: 150 },
  { label: "Extra Sauce",          price: 60  },
  { label: "Stuffed Crust Upgrade",price: 250 },
];

/* ─────────────────── Pizza Flavour List ─────────────────── */
// Auto-built from all pizza categories for use in deal modals
const PIZZA_FLAVORS = CATEGORIES
  .filter(c => c.isPizza)
  .flatMap(c => c.items.map(i => i.name));

/* ─────────────────── Compute item types & IDs ─────────────────── */
let __counter = 0;
CATEGORIES.forEach(cat => {
  cat.items.forEach(item => {
    item.id       = `${cat.id}-${__counter++}`;
    item.category = cat.label;

    // type: "pizza" | "deal" | "simple"
    if (cat.isPizza) {
      item.type  = "pizza";
      item.sizes = PIZZA_SIZES.map(s => ({
        label:     s.label,
        price:     Math.round((item.price * s.multiplier) / 10) * 10,
        salePrice: Math.round((item.salePrice * s.multiplier) / 10) * 10,
      }));
    } else if (item.hasPizza) {
      item.type = "deal";   // pizza deal → needs flavor (+ size) picker
    } else {
      item.type = "simple"; // straight to cart
    }
  });
});

/* Flat list of all items (handy for lookup) */
const ALL_ITEMS = CATEGORIES.flatMap(c => c.items);

/* ─────────────────── Helpers ─────────────────── */
function formatPKR(amount) {
  return "Rs. " + Math.round(amount).toLocaleString("en-PK");
}

function discountPct(price, salePrice) {
  if (!salePrice || salePrice >= price) return 0;
  return Math.round(((price - salePrice) / price) * 100);
}
